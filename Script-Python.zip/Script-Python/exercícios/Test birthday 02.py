Dia=input('Qual o dia do seu nascimento? ')
Mês=input('Qual o mês do seu nascimento? ')
Ano=input('Qual o ano do seu nascimento? ')
print('Então, você nasceu no dia', Dia, 'no mês', Mês, 'no ano de', Ano, '. Estou certo?')
