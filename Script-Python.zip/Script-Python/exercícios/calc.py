#Essa primeira linha define as saudações
n=str(input('Olá, seja bem vindo, digite seu nome:'))
#Essa linha de
print('Olá, {}! Seja bem vindo, vamos calcular quantos dólares você pode comprar'.format(n))
R=float(input('Primeiro, digite quantos reais você possui:R$'))
D=R/5.30
print('Com R${:.2f} você consegue comprar ${:.2f}!'.format(R,D))